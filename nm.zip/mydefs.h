#pragma once

#define H 4
#define W 5
#define MAXLIST 100000

typedef struct {
    unsigned char a[H][W];
} board;
